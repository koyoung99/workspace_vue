<template>
    <div>
        1-1) 이름을 작성하세요<br>
            >> 김아영<br>
        1-2)  vue-myclass 프로젝트를 생성하고 사용한 명령어를 작성하세요<br>
            >> vue create vue-my-class <br>
        1-3) 라우터를 vue-myclass에 추가하고 사용한 명령어를 작성하세요<br>
            >> vue add router<br>
        1-4) axios를 vue-myclass에 추가하고 사용한 명령어를 작성하세요<br>
            >> npm install axios
    </div>
</template>


<script>

export default {
    name: "MainView",
    components: {},
    data() {
        return {};
    },
    methods: {},
    created(){}
};
</script>


<style></style>